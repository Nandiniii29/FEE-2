# ShopEase — Mini E-commerce with React + Redux Toolkit

## Requirements
- Node.js 18 or newer
- npm

## Run the project
1. Extract the ZIP.
2. Open the extracted `mini-ecommerce-redux` folder in VS Code.
3. Open Terminal in that folder.
4. Run:
   ```bash
   npm install
   npm run dev
   ```
5. Open the local URL shown by Vite (usually http://localhost:5173).

## Features
- React Router pages: Home, Products, Cart, About, Checkout, and 404.
- Redux Toolkit `configureStore()` and `createSlice()`.
- Required cart reducers: `addToCart`, `removeFromCart`, `increaseQuantity`, `decreaseQuantity`, `clearCart`.
- Redux `Provider`, `useSelector()`, and `useDispatch()`.
- `Link`, `NavLink`, and `useNavigate()`.
- Navbar item count, cart subtotal/total, empty-cart message, active nav links, add-to-cart confirmation.
- Search and category filter.
- Cart persistence via localStorage.
- Demo checkout with order summary and confirmation. No real payment is taken.
- Responsive, basic CSS.

## Main files
- `src/store.js` — Redux store
- `src/features/cart/cartSlice.js` — cart state and reducers
- `src/router.jsx` — routes
- `src/components/Navbar.jsx` — navigation and cart count
- `src/pages/Products.jsx` — product search/filter
- `src/pages/Cart.jsx` — quantities, removal, total
- `src/pages/Checkout.jsx` — demo checkout
- `src/styles.css` — styling

## Notes
Product images are loaded from Unsplash over the internet. If one fails, a placeholder image is shown.
