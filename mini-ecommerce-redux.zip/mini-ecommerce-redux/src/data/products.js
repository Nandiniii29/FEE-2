export const products = [
  { id: 1, name: "Everyday Backpack", price: 1299, category: "Accessories", image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&q=80" },
  { id: 2, name: "Wireless Headphones", price: 2499, category: "Electronics", image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600&q=80" },
  { id: 3, name: "Classic Sneakers", price: 1999, category: "Fashion", image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80" },
  { id: 4, name: "Ceramic Coffee Mug", price: 399, category: "Home", image: "https://images.unsplash.com/photo-1514228742587-6b1558fd?auto=format&fit=crop&w=600&q=80" },
  { id: 5, name: "Smart Watch", price: 3299, category: "Electronics", image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&q=80" },
  { id: 6, name: "Desk Lamp", price: 899, category: "Home", image: "https://images.unsplash.com/photo-1507457379470-08b800bebc67?w=600&q=80" },
  { id: 7, name: "Sunglasses", price: 699, category: "Accessories", image: "https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=600&q=80" },
  { id: 8, name: "Travel Water Bottle", price: 549, category: "Accessories", image: "https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=600&q=80" }
];