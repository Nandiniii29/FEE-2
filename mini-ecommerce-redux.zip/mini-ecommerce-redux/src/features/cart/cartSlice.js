import { createSlice } from "@reduxjs/toolkit";

const loadCart = () => {
  try {
    const savedCart = localStorage.getItem("shopease-cart");
    return savedCart ? JSON.parse(savedCart) : [];
  } catch {
    return [];
  }
};

const cartSlice = createSlice({
  name: "cart",
  initialState: {
    items: loadCart(),
    notice: ""
  },
  reducers: {
    addToCart(state, action) {
      const product = action.payload;
      const existing = state.items.find((item) => item.id === product.id);
      if (existing) {
        existing.quantity += 1;
      } else {
        state.items.push({ ...product, quantity: 1 });
      }
      state.notice = `${product.name} added to your cart!`;
    },
    removeFromCart(state, action) {
      state.items = state.items.filter((item) => item.id !== action.payload);
      state.notice = "Item removed from your cart.";
    },
    increaseQuantity(state, action) {
      const item = state.items.find((product) => product.id === action.payload);
      if (item) item.quantity += 1;
    },
    decreaseQuantity(state, action) {
      const item = state.items.find((product) => product.id === action.payload);
      if (item) {
        if (item.quantity > 1) item.quantity -= 1;
        else state.items = state.items.filter((product) => product.id !== action.payload);
      }
    },
    clearCart(state) {
      state.items = [];
      state.notice = "";
    },
    clearNotice(state) {
      state.notice = "";
    }
  }
});

export const {
  addToCart,
  removeFromCart,
  increaseQuantity,
  decreaseQuantity,
  clearCart,
  clearNotice
} = cartSlice.actions;

export default cartSlice.reducer;