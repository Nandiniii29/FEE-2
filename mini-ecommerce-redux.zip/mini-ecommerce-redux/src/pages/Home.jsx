import { Link, useNavigate } from "react-router-dom";

export default function Home() {
  const navigate = useNavigate();
  return (
    <section className="hero">
      <p className="eyebrow">WELCOME TO SHOPEASE</p>
      <h1>Your everyday finds, all in one place.</h1>
      <p className="hero-copy">Discover useful essentials, thoughtful accessories, and little upgrades for your day.</p>
      <div className="button-row">
        <button onClick={() => navigate("/products")}>Browse Products</button>
        <Link className="button secondary" to="/cart">View Cart</Link>
      </div>
    </section>
  );
}