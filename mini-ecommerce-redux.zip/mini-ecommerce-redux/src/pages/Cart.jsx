import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { decreaseQuantity, increaseQuantity, removeFromCart, clearCart } from "../features/cart/cartSlice";

const money = (amount) => `₹${amount.toLocaleString("en-IN")}`;

export default function Cart() {
  const items = useSelector((state) => state.cart.items);
  const dispatch = useDispatch();
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const count = items.reduce((sum, item) => sum + item.quantity, 0);

  if (items.length === 0) {
    return <section className="empty-state large-empty">
      <div className="empty-icon">🛍️</div><h1>Your cart is empty</h1>
      <p>Looks like you haven't added anything yet.</p>
      <Link className="button" to="/products">Explore Products</Link>
    </section>;
  }

  return (
    <section>
      <div className="page-heading"><p className="eyebrow">YOUR BAG</p><h1>Shopping Cart</h1><p>{count} item{count !== 1 ? "s" : ""} in your cart</p></div>
      <div className="cart-layout">
        <div className="cart-items">
          {items.map((item) => (
            <article className="cart-item" key={item.id}>
              <img src={item.image} alt={item.name} onError={(event) => { event.currentTarget.src = "https://placehold.co/200x160?text=Product"; }} />
              <div className="cart-item-details">
                <h3>{item.name}</h3><p className="category">{item.category}</p><p className="price">{money(item.price)}</p>
                <div className="quantity-control">
                  <button className="quantity-button" aria-label={`Decrease ${item.name}`} onClick={() => dispatch(decreaseQuantity(item.id))}>−</button>
                  <span>{item.quantity}</span>
                  <button className="quantity-button" aria-label={`Increase ${item.name}`} onClick={() => dispatch(increaseQuantity(item.id))}>+</button>
                  <button className="remove-button" onClick={() => dispatch(removeFromCart(item.id))}>Remove</button>
                </div>
              </div>
              <strong>{money(item.price * item.quantity)}</strong>
            </article>
          ))}
        </div>
        <aside className="summary">
          <h2>Order Summary</h2><div className="summary-line"><span>Subtotal ({count} items)</span><strong>{money(total)}</strong></div>
          <div className="summary-line"><span>Delivery</span><span>Free</span></div><hr />
          <div className="summary-line total-line"><span>Total</span><strong>{money(total)}</strong></div>
          <Link to="/checkout" className="button full-width">Proceed to Checkout</Link>
          <button className="text-button" onClick={() => dispatch(clearCart())}>Clear Cart</button>
        </aside>
      </div>
    </section>
  );
}