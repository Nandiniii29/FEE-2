import { Link } from "react-router-dom";

export default function NotFound() {
  return <section className="empty-state large-empty"><p className="eyebrow">404 ERROR</p><h1>Page not found</h1><p>Sorry, we couldn't find the page you're looking for.</p><Link className="button" to="/">Go to Home</Link></section>;
}