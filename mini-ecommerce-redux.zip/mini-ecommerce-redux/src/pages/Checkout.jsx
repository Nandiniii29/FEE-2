import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { clearCart } from "../features/cart/cartSlice";

const money = (amount) => `₹${amount.toLocaleString("en-IN")}`;

export default function Checkout() {
  const items = useSelector((state) => state.cart.items);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [placedOrder, setPlacedOrder] = useState(null);
  const total = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const count = items.reduce((sum, item) => sum + item.quantity, 0);

  function placeOrder(event) {
    event.preventDefault();
    if (!items.length) return;
    setPlacedOrder({ name, email, items: items.map((item) => ({ ...item })), total, count, orderNumber: `SE${Date.now().toString().slice(-6)}` });
    dispatch(clearCart());
    navigate("/checkout", { replace: true, state: { orderPlaced: true } });
  }

  if (placedOrder) {
    return <section className="confirmation-card">
      <div className="success-mark">✓</div><p className="eyebrow">ORDER CONFIRMED</p><h1>Thank you, {placedOrder.name}!</h1>
      <p>Your demo order has been placed successfully.</p><p><strong>Order number:</strong> {placedOrder.orderNumber}</p>
      <div className="order-summary"><h2>Order Summary</h2>
        {placedOrder.items.map((item) => <div className="summary-line" key={item.id}><span>{item.name} × {item.quantity}</span><strong>{money(item.price * item.quantity)}</strong></div>)}
        <hr /><div className="summary-line total-line"><span>Total paid</span><strong>{money(placedOrder.total)}</strong></div>
        <p className="muted">Confirmation for demo purposes only. No payment was collected.</p>
      </div>
      <button onClick={() => navigate("/products")}>Continue Shopping</button>
    </section>;
  }

  if (!items.length) return <section className="empty-state large-empty"><h1>No items to checkout</h1><p>Add some products before checking out.</p><Link className="button" to="/products">Browse Products</Link></section>;

  return <section className="checkout-layout">
    <div><p className="eyebrow">ALMOST THERE</p><h1>Checkout</h1><p>Enter your details to place a demo order.</p>
      <form className="checkout-form" onSubmit={placeOrder}>
        <label>Full name<input required value={name} onChange={(event) => setName(event.target.value)} placeholder="Your name" /></label>
        <label>Email address<input required type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="you@example.com" /></label>
        <button type="submit">Place Demo Order</button>
      </form>
    </div>
    <aside className="summary"><h2>Order Summary</h2>
      {items.map((item) => <div className="summary-line" key={item.id}><span>{item.name} × {item.quantity}</span><strong>{money(item.price * item.quantity)}</strong></div>)}
      <hr /><div className="summary-line"><span>Items</span><span>{count}</span></div><div className="summary-line total-line"><span>Total</span><strong>{money(total)}</strong></div>
      <Link to="/cart" className="text-button">Back to cart</Link>
    </aside>
  </section>;
}