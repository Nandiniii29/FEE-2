import { Link } from "react-router-dom";

export default function About() {
  return (
    <section className="about-page">
      <p className="eyebrow">OUR STORY</p>
      <h1>Shopping made simple.</h1>
      <p>ShopEase is a sample online store created to make everyday shopping straightforward. Browse a small collection of lifestyle, fashion, home, and electronics products, then manage everything in one convenient cart.</p>
      <p>This mini project demonstrates React components, React Router navigation, and Redux Toolkit state management. Cart items are saved in your browser so they remain after a refresh.</p>
      <Link className="button" to="/">Back to Home</Link>
    </section>
  );
}