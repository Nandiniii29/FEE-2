import { useMemo, useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { products } from "../data/products";
import { clearNotice } from "../features/cart/cartSlice";
import ProductCard from "../components/ProductCard";

export default function Products() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const notice = useSelector((state) => state.cart.notice);
  const dispatch = useDispatch();
  const categories = ["All", ...new Set(products.map((product) => product.category))];

  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => dispatch(clearNotice()), 3000);
    return () => clearTimeout(timer);
  }, [notice, dispatch]);

  const filteredProducts = useMemo(() => products.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = category === "All" || product.category === category;
    return matchesSearch && matchesCategory;
  }), [search, category]);

  return (
    <section>
      <div className="page-heading">
        <p className="eyebrow">THE COLLECTION</p>
        <h1>Our Products</h1>
        <p>Find something you'll love.</p>
      </div>
      {notice && <div className="toast" role="status">✓ {notice}</div>}
      <div className="filters">
        <input aria-label="Search products" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search products..." />
        <select aria-label="Filter by category" value={category} onChange={(event) => setCategory(event.target.value)}>
          {categories.map((item) => <option key={item}>{item}</option>)}
        </select>
      </div>
      {filteredProducts.length ? (
        <div className="product-grid">
          {filteredProducts.map((product) => <ProductCard key={product.id} product={product} />)}
        </div>
      ) : <p className="empty-state">No products match your search. Try another term or category.</p>}
    </section>
  );
}