import { useDispatch } from "react-redux";
import { addToCart } from "../features/cart/cartSlice";

export default function ProductCard({ product, onAdded }) {
  const dispatch = useDispatch();

  function handleAdd() {
    dispatch(addToCart(product));
    onAdded?.(product.name);
  }

  return (
    <article className="product-card">
      <img src={product.image} alt={product.name} onError={(event) => { event.currentTarget.src = "https://placehold.co/600x400?text=Product"; }} />
      <div className="product-info">
        <span className="category">{product.category}</span>
        <h3>{product.name}</h3>
        <p className="price">₹{product.price.toLocaleString("en-IN")}</p>
        <button onClick={handleAdd}>Add to Cart</button>
      </div>
    </article>
  );
}