import { Outlet } from "react-router-dom";
import Navbar from "./Navbar";

export default function Layout() {
  return (
    <>
      <Navbar />
      <main className="container"><Outlet /></main>
      <footer className="footer">© 2026 ShopEase · Simple shopping, made easy.</footer>
    </>
  );
}